
import java.io.IOException;

public class ReadConfigMain {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		GetPropertyValues properties = new GetPropertyValues();
		properties.getPropValues();

	}

}
