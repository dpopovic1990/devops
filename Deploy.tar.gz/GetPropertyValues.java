
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;



public class GetPropertyValues {

	String result = "";
	InputStream inputStream;
	
	public String getPropValues() throws IOException{
		
		try{
			Properties prop = new Properties();
			String propFileName = "config.properties";
			
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
			
			if(inputStream != null){
				prop.load(inputStream);		
			} else {
				throw new FileNotFoundException("Property file " + propFileName + " not found in class path.");
			}
			
			String user_name = prop.getProperty("user_name");
			String password = prop.getProperty("password");
			String file_path = prop.getProperty("file_path");
			String speed = prop.getProperty("speed");
			String url = prop.getProperty("url");
			
			result = "Korisnicko ime: "+ user_name +"\n"
					+ "Korisnicka lozinka: "+ password +"\n"
					+ "Putanja do datoteke: "+ file_path +"\n"
					+ "Brzina: "+ speed +"\n"
					+ "URL: "+ url;
			
			System.out.println("Konfiguracijski parametri su sljedeci:\n" + result);
		} catch (Exception e){
			System.out.println("Exception: "+ e);
		} finally{
			inputStream.close();
		}
		return result;
		
	}
	
}

